﻿/// <reference path="E:\Project\Git\OnlineShop.Web\Assets/admin/libs/angular/angular.js" />

(function () {
    angular.module("onlineshop.common", ['ui.router', 'ngBootbox', 'checklist-model', 'ui.bootstrap','ngCkeditor']);
})();