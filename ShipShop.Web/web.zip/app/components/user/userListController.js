﻿(function (app){
    app.controller('userListController', userListController);
    userListController.$inject = ['$scope'];
    function userListController($scope) {

    }
})(angular.module('onlineshop.user'))